const { User } = require('../models');

class UserRepository {
    // Create a new user
    async createUser(userData) {
        return await User.create(userData);
    }

    // Find a user by ID
    async findUserById(userId) {
        return await User.findByPk(userId);
    }

    // Find a user by email (useful for authentication)
    async findUserByEmail(email) {
        return await User.findOne({ where: { email } });
    }

    // Update a user's information
    async updateUser(userId, updateData) {
        return await User.update(updateData, { where: { id: userId } });
    }

    // Delete a user by ID (optional, if needed)
    async deleteUser(userId) {
        return await User.destroy({ where: { id: userId } });
    }

    // Fetch all users (optional, for admin use)
    async findAllUsers() {
        return await User.findAll();
    }
}

module.exports = new UserRepository();
