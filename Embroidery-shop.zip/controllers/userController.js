const UserRepository = require('../repository/userRepository');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class UserController {
    // Register a new user
    async register(req, res) {
        try {
            const { name, email, password } = req.body;

            // Hash the password
            const hashedPassword = await bcrypt.hash(password, 10);

            // Create the user
            const newUser = await UserRepository.createUser({
                name,
                email,
                password: hashedPassword,
            });

            res.status(201).json(newUser);
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    }

    // Authenticate a user
    async login(req, res) {
        try {
            const { email, password } = req.body;

            // Find the user by email
            const user = await UserRepository.findUserByEmail(email);

            // Validate user and password
            if (!user || !(await bcrypt.compare(password, user.password))) {
                throw new Error('Invalid email or password');
            }

            // Generate a JWT token (for example purposes)
            const token = jwt.sign({ id: user.id, email: user.email }, 'secret_key', {
                expiresIn: '1h',
            });

            res.status(200).json({ message: 'Login successful', token });
        } catch (err) {
            res.status(401).json({ error: err.message });
        }
    }

    // Get user profile by ID
    async getProfile(req, res) {
        try {
            const userId = req.params.id;

            // Fetch the user profile
            const user = await UserRepository.findUserById(userId);

            if (!user) {
                return res.status(404).json({ message: 'User not found' });
            }

            res.status(200).json(user);
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    }

    // Update user profile
    async updateProfile(req, res) {
        try {
            const userId = req.params.id;
            const updateData = req.body;

            // Update the user's information
            const updatedUser = await UserRepository.updateUser(userId, updateData);

            if (!updatedUser) {
                return res.status(404).json({ message: 'User not found' });
            }

            res.status(200).json({ message: 'User updated successfully' });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    }
}

module.exports = new UserController();
